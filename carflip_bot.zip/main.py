
import os
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

API_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start', 'help'])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Это CarFlip бот. Оповещу тебя о новых авто на продажу.")

@dp.message_handler()
async def echo(message: types.Message):
    await message.answer("Скоро здесь будут фильтры по авто.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
