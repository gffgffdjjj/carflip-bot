import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
from aiogram.dispatcher.filters import CommandStart

API_TOKEN = "7764554746:AAFSJlWHvaTGxM1QyEns6Gnee5c_w9d1gT8"

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(CommandStart())
async def send_welcome(message: Message):
    await message.answer("Привет! Я бот CarFlip. Я пришлю тебе свежие объявления о продаже авто.")

@dp.message_handler(commands=["demo"])
async def demo_ad(message: Message):
    demo_text = "Новая машина в продаже!\nМарка: Toyota\nГод: 2015\nЦена: 30,000₪\nСсылка: https://example.com/car123"
    await message.answer(demo_text)

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)